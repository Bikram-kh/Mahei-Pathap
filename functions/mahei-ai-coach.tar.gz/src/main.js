const GEMINI_MODEL = "gemini-2.5-flash";

export default async ({ req, res, log, error }) => {
  try {
    if (req.method !== "POST") {
      return res.json(
        { success: false, error: "Only POST requests are allowed." },
        405
      );
    }

    const body = typeof req.body === "string"
      ? JSON.parse(req.body || "{}")
      : (req.body || {});

    const message = String(body.message || "").trim();

    if (!message) {
      return res.json(
        { success: false, error: "Message is required." },
        400
      );
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      error("GEMINI_API_KEY is not configured.");
      return res.json(
        { success: false, error: "AI service is not configured." },
        500
      );
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              {
                text: `You are Mahei Pathap AI Coach, a friendly and practical study assistant for students.

Help students:
- understand what to study
- break difficult work into smaller steps
- overcome procrastination
- stay focused
- plan study sessions

Give concise, actionable answers.
Do not pretend to know the student's personal data unless it is provided to you.`,
              },
            ],
          },
          contents: [
            {
              role: "user",
              parts: [{ text: message }],
            },
          ],
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      error(`Gemini API error: ${JSON.stringify(data)}`);

      return res.json(
        {
          success: false,
          error: "The AI service returned an error.",
        },
        502
      );
    }

    const reply =
      data?.candidates?.[0]?.content?.parts
        ?.map((part) => part.text || "")
        .join("")
        .trim();

    if (!reply) {
      return res.json(
        {
          success: false,
          error: "The AI returned an empty response.",
        },
        502
      );
    }

    log("AI Coach response generated successfully.");

    return res.json({
      success: true,
      reply,
    });
  } catch (err) {
    error(`AI Coach error: ${err.message}`);

    return res.json(
      {
        success: false,
        error: "Something went wrong while contacting the AI coach.",
      },
      500
    );
  }
};
